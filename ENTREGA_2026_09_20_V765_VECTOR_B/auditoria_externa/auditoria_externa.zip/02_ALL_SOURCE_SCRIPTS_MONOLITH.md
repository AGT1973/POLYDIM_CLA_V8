# 📜 MONOLITO DE CÓDIGOS FUENTES COMPLETOS (POLYDIM V762 MPELEIDES HARDENED)

> **Document:** `02_ALL_SOURCE_SCRIPTS_MONOLITH.md`  
> **Delivery Directory:** `E:\POLYDIM_EINSOF\ENTREGA_2026_09_19_V762\`  
> **Status:** Silicon Certified (26/26 C++ Tests PASS | 8/8 Rust Tests PASS | Exit Code 0)  

---

## 1. `include/polydim.h` (Public C/C++ Contract & Strict Numerical Policy)

```c
/* ============================================================================
 * POLYDIM V762 — CONTRATO PÚBLICO
 * Endurecimiento de V761. Cierra los 12 hallazgos de la auditoría 2026-09-20.
 *
 * POLÍTICA NUMÉRICA (leer antes de compilar):
 *   - Este kernel NO es IEEE-754 estricto si se compila con POLYDIM_ENABLE_FTZ=1,
 *     porque FTZ/DAZ no es compatible con IEEE-754 (Intel SDM vol.1 §10.2.3.3).
 *     Por defecto POLYDIM_ENABLE_FTZ=0 -> conformidad IEEE-754.
 *   - La sumación compensada de Neumaier EXIGE que el compilador no reasocie.
 *     Compilar con -fno-fast-math -fno-associative-math  (GCC/Clang)
 *                 /fp:precise                            (MSVC)
 *     El test polydim_selftest_compensation() falla si esto no se respetó.
 *
 * CONVENCIÓN DE ROTACIÓN (cambio incompatible respecto de V761):
 *   polydim_rodrigues_* aplica la rotación CANÓNICA R(+theta):
 *       R y = y + (cos t - 1)(<y,u>u + <y,v>v) + sin t (<y,u>v - <y,v>u)
 *   V761 aplicaba R(-theta). Para reproducir V761 exactamente, pasar -theta.
 * ==========================================================================*/
#ifndef POLYDIM_H
#define POLYDIM_H

#include <stdint.h>

#if defined(_WIN32)
  #define POLYDIM_EXPORT __declspec(dllexport)
  #define POLYDIM_CALL   __cdecl
#else
  #define POLYDIM_EXPORT __attribute__((visibility("default")))
  #define POLYDIM_CALL
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef enum PolydimStatus {
    POLYDIM_SUCCESS                  =  0,
    POLYDIM_ERR_NULL_POINTER         = -1,
    POLYDIM_ERR_INVALID_DIMENSION    = -2,
    POLYDIM_ERR_NAN_OR_INF           = -3,
    POLYDIM_ERR_DEGENERATE_NORM      = -4,
    POLYDIM_ERR_NUMERICAL_INSTABILITY= -5,
    POLYDIM_ERR_SEQLOCK_RACE         = -6,
    POLYDIM_ERR_BUFFER_OVERFLOW      = -7,
    POLYDIM_ERR_INVALID_SCALAR       = -8,  /* theta/tau no finito            (A3) */
    POLYDIM_ERR_BASIS_NOT_ORTHONORMAL= -9,  /* {u,v} no ortonormal            (A2) */
    POLYDIM_ERR_POINT_OFF_MANIFOLD   = -10, /* ||y|| != 1 en la entrada       (A4) */
    POLYDIM_ERR_ALIASED_BUFFERS      = -11, /* solapamiento ilegal de punteros     */
    POLYDIM_ERR_COMPENSATION_BROKEN  = -12  /* el compilador reasoció (A11)        */
} PolydimStatus;

typedef struct PolydimTolerances {
    double basis_ortho;
    double point_norm;
    double gram_ortho;
    double pivot_rel;
    int    reject_subnormal;
} PolydimTolerances;

POLYDIM_EXPORT PolydimTolerances POLYDIM_CALL polydim_default_tolerances(uint64_t D);

typedef struct PolydimReport {
    double point_norm_err;
    double basis_uu_err;
    double basis_vv_err;
    double basis_uv_err;
    double out_norm_err;
    double pivot_min;
    double pivot_threshold;
    double ortho_err;
    uint64_t threads_used;
} PolydimReport;

POLYDIM_EXPORT void POLYDIM_CALL polydim_report_init(PolydimReport* r);

POLYDIM_EXPORT int32_t POLYDIM_CALL polydim_rodrigues_geodesic_f64(
    const double* y, const double* u, const double* v, double* y_out,
    double theta, uint64_t D,
    const PolydimTolerances* tol,
    PolydimReport* report);

POLYDIM_EXPORT int32_t POLYDIM_CALL polydim_project_sphere_f64(
    const double* y, double* y_out, uint64_t D, PolydimReport* report);

POLYDIM_EXPORT int32_t POLYDIM_CALL polydim_orthonormalize_pair_f64(
    double* u, double* v, uint64_t D, PolydimReport* report);

POLYDIM_EXPORT int32_t POLYDIM_CALL polydim_stiefel_cayley_smw_f64(
    const double* X, const double* G, double* Y_out,
    uint64_t D, uint32_t K, double tau,
    const PolydimTolerances* tol, PolydimReport* report);

POLYDIM_EXPORT int32_t POLYDIM_CALL polydim_project_tangent_stiefel_f64(
    const double* X, const double* G, double* G_out,
    uint64_t D, uint32_t K);

#define POLYDIM_PMTP_SLOTS 3
typedef struct PMTP_Control PMTP_Control;

POLYDIM_EXPORT uint64_t POLYDIM_CALL polydim_pmtp_sizeof(void);
POLYDIM_EXPORT uint64_t POLYDIM_CALL polydim_pmtp_alignof(void);
POLYDIM_EXPORT void     POLYDIM_CALL polydim_pmtp_init(PMTP_Control* c);
POLYDIM_EXPORT int32_t POLYDIM_CALL polydim_pmtp_begin_write(PMTP_Control* c, uint64_t* slot_out);
POLYDIM_EXPORT int32_t POLYDIM_CALL polydim_pmtp_commit_write(PMTP_Control* c, uint64_t slot);
POLYDIM_EXPORT int32_t POLYDIM_CALL polydim_pmtp_acquire_read(
    PMTP_Control* c, uint64_t* observed_seq, uint64_t* slot_out, uint64_t* ticket_out);
POLYDIM_EXPORT int32_t POLYDIM_CALL polydim_pmtp_validate_read(
    const PMTP_Control* c, uint64_t slot, uint64_t ticket);

POLYDIM_EXPORT int32_t POLYDIM_CALL polydim_selftest_compensation(double* observed_err);
POLYDIM_EXPORT int32_t POLYDIM_CALL polydim_selftest_all(void);
POLYDIM_EXPORT const char* POLYDIM_CALL polydim_status_string(int32_t code);
POLYDIM_EXPORT const char* POLYDIM_CALL polydim_build_info(void);

#ifdef __cplusplus
}
#endif
#endif
```

---

## 2. `src/polydim_kernel.cpp` (Hardened C++ Kernel)

*(Ver código fuente completo en [`src/polydim_kernel.cpp`](file:///E:/POLYDIM_EINSOF/ENTREGA_2026_09_19_V762/src/polydim_kernel.cpp) y [`kernel_cpp_v762.cpp.txt`](file:///E:/POLYDIM_EINSOF/ENTREGA_2026_09_19_V762/kernel_cpp_v762.cpp.txt))*

---

## 3. `rust/src/lib.rs` (Rust 2024 Guard with $64\epsilon$ Bound)

*(Ver código fuente completo en [`rust/src/lib.rs`](file:///E:/POLYDIM_EINSOF/ENTREGA_2026_09_19_V762/rust/src/lib.rs) y [`kernel_rust_v762.rs.txt`](file:///E:/POLYDIM_EINSOF/ENTREGA_2026_09_19_V762/kernel_rust_v762.rs.txt))*

---

## 4. `dart/polydim_ffi.dart` (Dart FFI Bridge with Real Execution & Auto-Free)

*(Ver código fuente completo en [`dart/polydim_ffi.dart`](file:///E:/POLYDIM_EINSOF/ENTREGA_2026_09_19_V762/dart/polydim_ffi.dart) y [`polydim_ffi_v762.dart`](file:///E:/POLYDIM_EINSOF/ENTREGA_2026_09_19_V762/polydim_ffi_v762.dart))*

---

## 5. `polydim_v762_monolito.py` (Zero-Copy PMTP Monolith Orchestrator)

*(Ver código fuente completo en [`polydim_v762_monolito.py`](file:///E:/POLYDIM_EINSOF/ENTREGA_2026_09_19_V762/polydim_v762_monolito.py))*

---

## 6. `polydim_triton_kernel_v762.py` (GPU Triton Extension)

*(Ver código fuente completo en [`polydim_triton_kernel_v762.py`](file:///E:/POLYDIM_EINSOF/ENTREGA_2026_09_19_V762/polydim_triton_kernel_v762.py))*

---

## 7. `tests/test_suite.cpp` (26 Physical Silicon Validation Tests)

*(Ver suite completa en [`tests/test_suite.cpp`](file:///E:/POLYDIM_EINSOF/ENTREGA_2026_09_19_V762/tests/test_suite.cpp))*
