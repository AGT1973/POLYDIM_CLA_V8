import 'dart:ffi';
import 'dart:typed_data';

final DynamicLibrary polydimLib = DynamicLibrary.open('polydim_cpp_v735.dll');

class PolyDimEngine {
  final _precomputeIsometryComposition = polydimLib.lookupFunction<
      Void Function(Pointer<Uint64>, Pointer<Uint64>, Pointer<Uint64>, Pointer<Uint64>, Int32, Int32),
      void Function(Pointer<Uint64>, Pointer<Uint64>, Pointer<Uint64>, Pointer<Uint64>, int, int)>('precompute_isometry_composition');

  final _householderSingleStepF32 = polydimLib.lookupFunction<
      Void Function(Pointer<Float>, Pointer<Float>, Int32),
      void Function(Pointer<Float>, Pointer<Float>, int)>('householder_single_step_f32');

  final _computeL2NormF64Accum = polydimLib.lookupFunction<
      Double Function(Pointer<Float>, Int32),
      double Function(Pointer<Float>, int)>('compute_l2_norm_f64_accum');

  final _computeHammingWeight = polydimLib.lookupFunction<
      Uint64 Function(Pointer<Uint64>, Int32),
      int Function(Pointer<Uint64>, int)>('compute_hamming_weight');

  final _applyCayleySmwRetractionF32 = polydimLib.lookupFunction<
      Void Function(Pointer<Float>, Pointer<Float>, Pointer<Float>, Float, Int32),
      void Function(Pointer<Float>, Pointer<Float>, Pointer<Float>, double, int)>('apply_cayley_smw_retraction_f32');

  void precomputeIsometryComposition(Pointer<Uint64> pIn, Pointer<Uint64> mIn, Pointer<Uint64> pOut, Pointer<Uint64> mOut, int d, int k) {
    _precomputeIsometryComposition(pIn, mIn, pOut, mOut, d, k);
  }

  void householderSingleStepF32(Pointer<Float> tensor, Pointer<Float> v, int d) {
    _householderSingleStepF32(tensor, v, d);
  }

  double computeL2NormF64Accum(Pointer<Float> tensor, int d) {
    return _computeL2NormF64Accum(tensor, d);
  }

  int computeHammingWeight(Pointer<Uint64> tensor, int dBlocks) {
    return _computeHammingWeight(tensor, dBlocks);
  }

  void applyCayleySmwRetractionF32(Pointer<Float> y, Pointer<Float> u, Pointer<Float> v, double alpha, int d) {
    _applyCayleySmwRetractionF32(y, u, v, alpha, d);
  }
}
