# POLYDIM V732 INDUSTRIAL - TRITON GPU KERNEL
# Fused-In-Place Householder Reflection
# Zero .item() calls - everything stays in VRAM
# Graceful degradation: if triton not available, provides CPU fallback

import torch

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except ImportError:
    TRITON_AVAILABLE = False

if TRITON_AVAILABLE:
    @triton.jit
    def triton_dot_product_kernel(tensor_ptr, v_ptr, output_ptr, D, BLOCK_SIZE: tl.constexpr):
        pid = tl.program_id(axis=0)
        block_start = pid * BLOCK_SIZE
        offsets = block_start + tl.arange(0, BLOCK_SIZE)
        mask = offsets < D
        
        # Load data
        tensor_vals = tl.load(tensor_ptr + offsets, mask=mask, other=0.0)
        v_vals = tl.load(v_ptr + offsets, mask=mask, other=0.0)
        
        # Cast to float64 BEFORE multiplication to prevent precision loss (V733 INDUSTRIAL)
        tensor_vals_f64 = tensor_vals.to(tl.float64)
        v_vals_f64 = v_vals.to(tl.float64)
        
        # Dot product partial in f64
        dot_vals_f64 = tensor_vals_f64 * v_vals_f64
        
        # Block-local reduction
        block_sum = tl.sum(dot_vals_f64, axis=0)
        
        # Atomic add to the output pointer
        tl.atomic_add(output_ptr, block_sum)

    @triton.jit
    def triton_householder_kernel(tensor_ptr, v_ptr, dot_value_ptr, D, BLOCK_SIZE: tl.constexpr):
        pid = tl.program_id(axis=0)
        block_start = pid * BLOCK_SIZE
        offsets = block_start + tl.arange(0, BLOCK_SIZE)
        mask = offsets < D
        
        # Read the scalar dot product computed by the first kernel
        dot_value = tl.load(dot_value_ptr)
        
        # Load tensor and v
        tensor_vals = tl.load(tensor_ptr + offsets, mask=mask)
        v_vals = tl.load(v_ptr + offsets, mask=mask)
        
        # Math: tensor -= 2.0 * dot_value * v
        # Cast dot_value (f64) down to the expected float32 space if needed
        # We rely on implicit casting for the math, then triton will handle store cast
        new_tensor_vals = tensor_vals - 2.0 * dot_value.to(tl.float32) * v_vals
        
        # Store back in-place
        tl.store(tensor_ptr + offsets, new_tensor_vals, mask=mask)

def householder_single_step_gpu(tensor: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    """
    Applies a Householder reflection to 'tensor' in place, using vector 'v'.
    Zero CPU round-trips.
    """
    if TRITON_AVAILABLE and tensor.is_cuda and v.is_cuda:
        D = tensor.numel()
        
        # Pre-allocate output scalar for dot product as float64 (prevent mantissa collapse)
        dot_value = torch.zeros(1, dtype=torch.float64, device=tensor.device)
        
        BLOCK_SIZE = 1024
        grid = lambda meta: (triton.cdiv(D, meta['BLOCK_SIZE']),)
        
        triton_dot_product_kernel[grid](
            tensor, v, dot_value, D, BLOCK_SIZE=BLOCK_SIZE
        )
        
        triton_householder_kernel[grid](
            tensor, v, dot_value, D, BLOCK_SIZE=BLOCK_SIZE
        )
        return tensor
    else:
        # Graceful degradation (PyTorch fallback, no .item())
        # Accumulate in float64
        dot_value = torch.dot(tensor.to(torch.float64), v.to(torch.float64))
        tensor.sub_(2.0 * dot_value.to(tensor.dtype) * v)
        return tensor

def generate_random_unit_vector_gpu(D: int, device: str) -> torch.Tensor:
    """
    Generates a random unit vector on the GPU.
    Uses float64 for intermediate norm calculation to prevent mantissa collapse.
    """
    v = torch.randn(D, device=device, dtype=torch.float64)
    norm = torch.norm(v)
    return (v / norm).to(torch.float32)

def compute_l2_norm_gpu(tensor: torch.Tensor) -> torch.Tensor:
    """
    Returns L2 norm as a 1-element CUDA tensor.
    """
    return torch.norm(tensor.to(torch.float64)).unsqueeze(0)
