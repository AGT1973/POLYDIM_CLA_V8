"""
PMTP SCIENTIFIC PROOF - T5 Encoder-Decoder IPC
===============================================
Agente A (EL OJO): Encoder T5 - Lee texto, genera tensor, lo vuelca en Shared Memory.
Agente B (LA BOCA): Decoder T5 - Se despierta CIEGO al texto. Lee tensor crudo desde PMTP.
                    Colapsa al 2D humano escribiendo el resultado.

Prueba científica irrebatible: A nunca le pasa texto a B. Solo un puntero.
"""

import torch
from transformers import T5Tokenizer, T5ForConditionalGeneration
import multiprocessing
from multiprocessing import shared_memory
import numpy as np
import time
import os
import ctypes
from ctypes import POINTER, c_float

os.environ["TOKENIZERS_PARALLELISM"] = "false"

MODEL_ID = 't5-small'

def agent_a_reader(secret_text, shm_name, shape, barrier):
    print("\n[AGENTE A - EL OJO] Iniciando. No tengo boca. Solo pienso en tensores.")
    tokenizer = T5Tokenizer.from_pretrained(MODEL_ID, legacy=False)
    model = T5ForConditionalGeneration.from_pretrained(MODEL_ID)
    
    print(f"[AGENTE A] Recibí del humano: '{secret_text}'")
    
    # 1. Tokenizar y encodear
    input_ids = tokenizer(secret_text, return_tensors="pt").input_ids
    with torch.no_grad():
        encoder_output = model.encoder(input_ids=input_ids)
        hidden_states = encoder_output.last_hidden_state.numpy().astype(np.float32)
    
    # 2. Abrir SHM que el orquestador ya creó, y volcar tensor
    shm = shared_memory.SharedMemory(name=shm_name)
    buf = np.ndarray(shape, dtype=np.float32, buffer=shm.buf)
    np.copyto(buf, hidden_states)
    
    print(f"[AGENTE A] Tensor {shape} volcado en PMTP SHM '{shm_name}'. Cero JSON. Cierro mi ojo.\n")
    
    # 3. Señalizar al orquestador que el tensor está listo
    barrier.wait()  # Agente A termina, Agente B puede leer
    shm.close()


def agent_b_writer(shm_name, shape, barrier):
    print("[AGENTE B - LA BOCA] Iniciando. Estoy CIEGO al texto original. Solo recibo tensores.")
    
    # 1. Esperar a que Agente A haya volcado el tensor
    barrier.wait()
    
    # 2. Leer el tensor crudo desde PMTP (Zero-Copy)
    t0 = time.perf_counter()
    shm = shared_memory.SharedMemory(name=shm_name)
    tensor_b = np.ndarray(shape, dtype=np.float32, buffer=shm.buf)
    encoder_hidden_states = torch.from_numpy(tensor_b.copy())
    t1 = time.perf_counter()
    
    print(f"[AGENTE B] Tensor PMTP recuperado en {t1-t0:.6f}s (Cero colapso a 1D)")
    print(f"[AGENTE B] Forma del tensor recibido: {encoder_hidden_states.shape}")
    
    # 3. Decodificar usando SOLO el tensor latente (la instrucción vivía ahí dentro)
    tokenizer = T5Tokenizer.from_pretrained(MODEL_ID, legacy=False)
    model = T5ForConditionalGeneration.from_pretrained(MODEL_ID)
    model.eval()
    
    # Crear attention mask (todos unos, secuencia completa)
    attention_mask = torch.ones(encoder_hidden_states.shape[:2], dtype=torch.long)
    
    print("[AGENTE B] Decodificando concepto latente hacia lenguaje humano (Colapso 2D)...")
    with torch.no_grad():
        generated_ids = model.generate(
            encoder_outputs=(encoder_hidden_states.to(model.dtype),),
            attention_mask=attention_mask,
            max_new_tokens=60
        )
    
    final_text = tokenizer.decode(generated_ids[0], skip_special_tokens=True)
    
    print(f"\n{'='*64}")
    print(f"[AGENTE B] TEXTO COLAPSADO DESDE EL TENSOR (Sin ver el original):")
    print(f"  >>> {final_text}")
    print(f"{'='*64}\n")
    
    shm.close()


if __name__ == '__main__':
    multiprocessing.freeze_support()
    
    # La instrucción secreta que solo verá el Agente A
    secret_concept = "translate English to French: The high dimensional tensor communicates natively without serializing to text."
    
    # El orquestador calcula el shape para crear la SHM ANTES de lanzar los procesos
    # T5-small encoder hidden dim = 512
    temp_tokenizer = T5Tokenizer.from_pretrained(MODEL_ID, legacy=False)
    seq_len = temp_tokenizer(secret_concept, return_tensors="pt").input_ids.shape[1]
    expected_shape = (1, seq_len, 512)
    shm_size = int(np.prod(expected_shape)) * 4  # float32 = 4 bytes
    shm_name = "pmtp_t5_proof"
    
    # Limpieza preventiva
    try:
        old = shared_memory.SharedMemory(name=shm_name)
        old.unlink()
        old.close()
    except:
        pass
    
    # Crear la SHM en el proceso principal (orquestador) para que exista para ambos hijos
    shm_main = shared_memory.SharedMemory(create=True, size=shm_size, name=shm_name)
    
    print(f"[ORQUESTADOR] SHM PMTP creada: {shm_size/1024:.2f} KB, nombre='{shm_name}'")
    print(f"[ORQUESTADOR] Shape del tensor: {expected_shape}")
    print(f"[ORQUESTADOR] Lanzando Agente A (EL OJO) y Agente B (LA BOCA)...\n")
    
    # Barrier para sincronizar: B espera a que A termine de escribir
    barrier = multiprocessing.Barrier(2)
    
    p_a = multiprocessing.Process(target=agent_a_reader, args=(secret_concept, shm_name, expected_shape, barrier))
    p_b = multiprocessing.Process(target=agent_b_writer, args=(shm_name, expected_shape, barrier))
    
    p_a.start()
    p_b.start()
    
    p_a.join()
    p_b.join()
    
    shm_main.close()
    shm_main.unlink()
    print("[ORQUESTADOR] SHM liberada. Prueba finalizada.")
