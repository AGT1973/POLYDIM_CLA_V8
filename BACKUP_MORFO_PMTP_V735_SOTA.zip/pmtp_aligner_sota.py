#!/usr/bin/env python3
# pmtp_aligner_sota.py -- POLYDIM V735
# Aprendizaje Analítico de W para Traducción PMTP (2048 -> 896)
# 16GB SAFE: Extrae secuencialmente y usa Pseudoinversa de Moore-Penrose.

import os, sys, gc, time
import torch
import numpy as np
from transformers import AutoTokenizer, AutoModelForCausalLM

os.environ["TOKENIZERS_PARALLELISM"] = "false"
import warnings; warnings.filterwarnings("ignore", category=UserWarning)

MODEL_A = r"E:\POLYDIM_EINSOF\_HISTORICO\models\tinyllama_1_1b"
MODEL_B = r"E:\POLYDIM_EINSOF\_HISTORICO\models\qwen_0_5b"

# Anclas Semanticas Universales (forzamos que sean tokens únicos lo más posible)
ANCHORS = [
    "System", "Data", "Time", "Computer", "Brain", "Neural", "Space", 
    "Light", "Power", "Logic", "Matrix", "Code", "Future", "Machine", 
    "Energy", "Signal", "Input", "Output", "Memory", "Vision"
]

def get_latents(model_path, dim):
    print(f"\n--- Extrayendo de {os.path.basename(model_path)} ---")
    tok = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    mdl = AutoModelForCausalLM.from_pretrained(
        model_path, local_files_only=True, dtype=torch.float16
    )
    mdl.eval()
    
    latents = []
    for word in ANCHORS:
        inputs = tok(word, return_tensors="pt")
        with torch.no_grad():
            out = mdl(**inputs, output_hidden_states=True)
        # Tomamos el ULTIMO token (representa la palabra)
        h = out.hidden_states[-1][0, -1, :].float().numpy()
        latents.append(h)
    
    del mdl, tok, inputs, out; gc.collect()
    return np.vstack(latents)  # (N, DIM)

if __name__ == "__main__":
    print("================================================================")
    print("  POLYDIM PMTP -- ALINEACION SEMANTICA DE MANIFOLDS (SOTA)")
    print("================================================================")
    
    t0 = time.perf_counter()
    
    # 1. Extraer X de TinyLlama (Emisor)
    X = get_latents(MODEL_A, 2048)  # (20, 2048)
    print(f"[+] Matriz X extraida: {X.shape}")
    
    # 2. Extraer Y de Qwen (Receptor Objetivo)
    Y = get_latents(MODEL_B, 896)   # (20, 896)
    print(f"[+] Matriz Y extraida: {Y.shape}")
    
    print("\n[+] Calculando Matriz de Traduccion W (Pseudoinversa Moore-Penrose)...")
    # Ecuacion: X @ W = Y   =>   W = X^+ @ Y
    # Usamos Regularizacion Ridge L2 minima para estabilidad
    alpha = 1e-3
    # (X^T X + alpha I)^-1 X^T Y
    XtX = X.T @ X
    XtX += np.eye(XtX.shape[0]) * alpha
    XtX_inv = np.linalg.pinv(XtX)
    W = XtX_inv @ X.T @ Y  # (2048, 896)
    
    print(f"[+] Matriz W calculada: {W.shape}, Norm media: {np.linalg.norm(W):.4f}")
    
    # Guardar W para que el Swarm lo consuma
    np.save("W_aligned.npy", W)
    
    # Evaluacion del Error de Reconstruccion (MSE)
    Y_pred = X @ W
    mse = np.mean((Y - Y_pred)**2)
    print(f"[+] Error de Reconstruccion (MSE) sobre anclas: {mse:.6f}")
    print(f"[+] Alineacion completa en {time.perf_counter() - t0:.2f}s")
    print("================================================================")