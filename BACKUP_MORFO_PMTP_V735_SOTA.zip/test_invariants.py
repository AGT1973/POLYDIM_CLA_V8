import unittest
import numpy as np
import sys

class TestHouseholderInvariants(unittest.TestCase):
    def test_single_reflection_preserves_norm(self):
        """A single Householder reflection is an isometry"""
        x = np.random.randn(1000).astype(np.float32)
        x /= np.linalg.norm(x)
        
        v = np.random.randn(1000).astype(np.float32)
        v /= np.linalg.norm(v)
        
        x_prime = x - 2 * np.dot(x, v) * v
        
        self.assertTrue(np.allclose(np.linalg.norm(x_prime), np.linalg.norm(x), atol=1e-5))

    def test_fresh_vectors_not_noop(self):
        """50 reflections with fresh vectors is not involutive"""
        x_orig = np.random.randn(1000).astype(np.float32)
        x_orig /= np.linalg.norm(x_orig)
        x = x_orig.copy()
        
        for _ in range(50):
            v = np.random.randn(1000).astype(np.float32)
            v /= np.linalg.norm(v)
            x = x - 2 * np.dot(x, v) * v
            
        self.assertFalse(np.allclose(x_orig, x, atol=1e-5))

    def test_same_vector_even_is_identity(self):
        """This test PROVES the V731 bug: same v + even N = No-Op"""
        x_orig = np.random.randn(1000).astype(np.float32)
        x_orig /= np.linalg.norm(x_orig)
        x = x_orig.copy()
        
        v = np.random.randn(1000).astype(np.float32)
        v /= np.linalg.norm(v)
        
        for _ in range(50):
            x = x - 2 * np.dot(x, v) * v
            
        self.assertTrue(np.allclose(x_orig, x, atol=1e-5))

    def test_dot_product_f64_vs_f32(self):
        """Show that f64 accumulation is more accurate"""
        x = np.random.randn(100000).astype(np.float32)
        y = np.random.randn(100000).astype(np.float32)
        
        dot_f32 = np.dot(x, y)
        dot_f64 = np.dot(x.astype(np.float64), y.astype(np.float64))
        
        self.assertNotEqual(dot_f32, np.float32(dot_f64))

    def test_norm_preservation_multiple_steps(self):
        """Accumulate max drift across all steps"""
        x = np.random.randn(1000).astype(np.float32)
        x /= np.linalg.norm(x)
        orig_norm = np.linalg.norm(x)
        
        max_drift = 0.0
        for _ in range(50):
            v = np.random.randn(1000).astype(np.float32)
            v /= np.linalg.norm(v)
            x = x - 2 * np.dot(x, v) * v
            current_norm = np.linalg.norm(x)
            drift = abs(current_norm - orig_norm)
            if drift > max_drift:
                max_drift = drift
                
        self.assertLess(max_drift, 1e-3)

class TestBSCInvariants(unittest.TestCase):
    def test_xor_random_destroys_information(self):
        """This test PROVES the V731 bug: random XOR = amnesia"""
        x = np.random.randint(0, 2, 1000, dtype=np.uint8)
        noise = np.random.randint(0, 2, 1000, dtype=np.uint8)
        y = x ^ noise
        
        corr = np.corrcoef(x, y)[0, 1]
        self.assertTrue(abs(corr) < 0.1)
        
    def test_fixed_permutation_mask_preserves_hamming(self):
        """Fixed permutation + fixed mask is a TRUE isometry"""
        a = np.random.randint(0, 2, 1000, dtype=np.uint8)
        b = np.random.randint(0, 2, 1000, dtype=np.uint8)
        
        perm = np.random.permutation(1000)
        mask = np.random.randint(0, 2, 1000, dtype=np.uint8)
        
        dist_orig = np.sum(a != b)
        
        a_prime = a[perm] ^ mask
        b_prime = b[perm] ^ mask
        
        dist_prime = np.sum(a_prime != b_prime)
        
        self.assertEqual(dist_orig, dist_prime)

    def test_bit63_full_range(self):
        """This test PROVES the V731 bug: randint(0, 2^63-1) freezes bit 63"""
        rng = np.random.default_rng()
        vals = rng.integers(0, 2**64, size=10000, dtype=np.uint64)
        msb_set = (vals & (np.uint64(1) << np.uint64(63))) != 0
        prop = np.mean(msb_set)
        
        self.assertTrue(0.45 <= prop <= 0.55)

    def test_bit63_old_bug(self):
        """Generate uint64 using np.random.randint(0, 2**63-1, dtype=np.uint64) and check that MSB is NEVER set"""
        try:
            vals = np.random.randint(0, 2**63-1, size=10000, dtype=np.uint64)
            msb_set = (vals & (np.uint64(1) << np.uint64(63))) != 0
            prop = np.mean(msb_set)
            self.assertEqual(prop, 0.0)
        except Exception:
            pass

    def test_isometry_reversible(self):
        """Assert original recovered exactly"""
        a = np.random.randint(0, 2, 1000, dtype=np.uint8)
        perm = np.random.permutation(1000)
        mask = np.random.randint(0, 2, 1000, dtype=np.uint8)
        
        inv_perm = np.empty_like(perm)
        inv_perm[perm] = np.arange(1000)
        
        a_prime = a[perm] ^ mask
        
        a_recovered = (a_prime ^ mask)[inv_perm]
        
        self.assertTrue(np.array_equal(a, a_recovered))

class TestVectorNullEdgeCases(unittest.TestCase):
    def test_zero_vector_householder(self):
        """Apply Householder to zero vector"""
        x = np.zeros(1000, dtype=np.float32)
        v = np.random.randn(1000).astype(np.float32)
        v /= np.linalg.norm(v)
        
        x_prime = x - 2 * np.dot(x, v) * v
        
        self.assertTrue(np.allclose(x, x_prime))

    def test_unit_basis_vector(self):
        """Apply Householder to e_1"""
        x = np.zeros(1000, dtype=np.float32)
        x[0] = 1.0
        
        v = np.random.randn(1000).astype(np.float32)
        v /= np.linalg.norm(v)
        
        x_prime = x - 2 * np.dot(x, v) * v
        
        self.assertTrue(np.allclose(np.linalg.norm(x_prime), 1.0, atol=1e-5))

    def test_all_ones_bsc(self):
        """BSC on all-ones vector"""
        a = np.ones(1000, dtype=np.uint8)
        b = np.zeros(1000, dtype=np.uint8)
        
        perm = np.random.permutation(1000)
        mask = np.random.randint(0, 2, 1000, dtype=np.uint8)
        
        dist_orig = np.sum(a != b)
        
        a_prime = a[perm] ^ mask
        b_prime = b[perm] ^ mask
        
        dist_prime = np.sum(a_prime != b_prime)
        
        self.assertEqual(dist_orig, dist_prime)

if __name__ == '__main__':
    unittest.main(verbosity=2)
