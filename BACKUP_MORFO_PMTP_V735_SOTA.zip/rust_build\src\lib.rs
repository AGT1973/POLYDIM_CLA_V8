// POLYDIM V732 INDUSTRIAL - RUST KERNEL (TOPOLOGICAL VALIDATORS)
// Compiled as cdylib for FFI via ctypes
// All functions #[no_mangle] extern "C"

#[no_mangle]
pub extern "C" fn check_l2_norm_f32(tensor: *const f32, length: usize) -> f64 {
    if tensor.is_null() {
        return -1.0;
    }
    if (tensor as usize) % std::mem::align_of::<f32>() != 0 {
        return -2.0;
    }
    if length == 0 {
        return 0.0;
    }

    let slice = unsafe { std::slice::from_raw_parts(tensor, length) };
    let mut sum: f64 = 0.0;
    for &val in slice {
        let v = val as f64;
        sum += v * v;
    }
    sum.sqrt()
}

#[no_mangle]
pub extern "C" fn check_hamming_weight(tensor: *const u64, length: usize) -> i64 {
    if tensor.is_null() {
        return -1;
    }
    if length == 0 {
        return 0;
    }

    let slice = unsafe { std::slice::from_raw_parts(tensor, length) };
    let mut count: i64 = 0;
    for &val in slice {
        count += val.count_ones() as i64;
    }
    count
}

#[no_mangle]
pub extern "C" fn check_pairwise_inner_products(tensor_a: *const f32, tensor_b: *const f32, length: usize) -> f64 {
    if tensor_a.is_null() || tensor_b.is_null() {
        return -1.0;
    }
    if length == 0 {
        return 0.0;
    }

    let slice_a = unsafe { std::slice::from_raw_parts(tensor_a, length) };
    let slice_b = unsafe { std::slice::from_raw_parts(tensor_b, length) };
    let mut sum: f64 = 0.0;
    
    for i in 0..length {
        sum += (slice_a[i] as f64) * (slice_b[i] as f64);
    }
    sum
}

#[no_mangle]
pub extern "C" fn check_hamming_distance(a: *const u64, b: *const u64, length: usize) -> i64 {
    if a.is_null() || b.is_null() {
        return -1;
    }
    if length == 0 {
        return 0;
    }

    let slice_a = unsafe { std::slice::from_raw_parts(a, length) };
    let slice_b = unsafe { std::slice::from_raw_parts(b, length) };
    let mut dist: i64 = 0;
    
    for i in 0..length {
        dist += (slice_a[i] ^ slice_b[i]).count_ones() as i64;
    }
    dist
}
