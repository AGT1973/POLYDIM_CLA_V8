import os
import sys
import time
import json
import ctypes
import platform
import numpy as np
import psutil
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any

# CONSTANTS
D = 100_000          # Asymptotic scale (NEVER reduce silently)
ITERATIONS = 50         # Householder / BSC steps
N_RUNS = 1             # Statistical runs
SEED_BASE = 42          # Fixed seed base

# ============================================================
# 1. HARDWARE INTERROGATION
# ============================================================
@dataclass
class HardwareInfo:
    cpu_cores_logical: int
    cpu_cores_physical: int
    ram_gb: float
    os_info: str
    page_size: int
    cuda_available: bool
    cuda_device_name: str

def get_hardware_info() -> HardwareInfo:
    try:
        import torch
        cuda_available = torch.cuda.is_available()
        cuda_device_name = torch.cuda.get_device_name(0) if cuda_available else ""
    except ImportError:
        cuda_available = False
        cuda_device_name = ""

    try:
        page_size = os.sysconf('SC_PAGE_SIZE')
    except (ValueError, AttributeError):
        page_size = 4096  # Standard fallback

    return HardwareInfo(
        cpu_cores_logical=psutil.cpu_count(logical=True) or 0,
        cpu_cores_physical=psutil.cpu_count(logical=False) or 0,
        ram_gb=psutil.virtual_memory().total / (1024**3),
        os_info=f"{platform.system()} {platform.release()} ({platform.architecture()[0]})",
        page_size=page_size,
        cuda_available=cuda_available,
        cuda_device_name=cuda_device_name
    )

# ============================================================
# 2. BACKEND REGISTRY
# ============================================================
@dataclass
class BackendInfo:
    name: str
    available: bool
    lib_path: Optional[str] = None
    lib_obj: Any = None

def load_cpp_backend() -> BackendInfo:
    ext = ".dll" if platform.system() == "Windows" else ".so"
    lib_path = Path(__file__).parent / f"polydim_cpp_v735{ext}"
    if not lib_path.exists():
        return BackendInfo("cpp_cpu", False)
    
    try:
        lib = ctypes.CDLL(str(lib_path))
        
        if hasattr(lib, 'bsc_xor_single_step'):
            lib.bsc_xor_single_step.argtypes = [ctypes.POINTER(ctypes.c_uint64), ctypes.c_int, ctypes.c_uint64]
            lib.bsc_xor_single_step.restype = None
            
        if hasattr(lib, 'bsc_isometry_single_step'):
            lib.bsc_isometry_single_step.argtypes = [
                ctypes.POINTER(ctypes.c_uint64), 
                ctypes.POINTER(ctypes.c_uint64), 
                ctypes.POINTER(ctypes.c_uint64), 
                ctypes.c_int
            ]
            lib.bsc_isometry_single_step.restype = None

        if hasattr(lib, 'precompute_isometry_composition'):
            lib.precompute_isometry_composition.argtypes = [
                ctypes.POINTER(ctypes.c_uint64),
                ctypes.POINTER(ctypes.c_uint64),
                ctypes.POINTER(ctypes.c_uint64),
                ctypes.POINTER(ctypes.c_uint64),
                ctypes.c_int,
                ctypes.c_int
            ]
            lib.precompute_isometry_composition.restype = None
            
        if hasattr(lib, 'householder_single_step_f32'):
            lib.householder_single_step_f32.argtypes = [
                ctypes.POINTER(ctypes.c_float), 
                ctypes.POINTER(ctypes.c_float), 
                ctypes.c_int
            ]
            lib.householder_single_step_f32.restype = None
            
        if hasattr(lib, 'compute_l2_norm_f64_accum'):
            lib.compute_l2_norm_f64_accum.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.c_int]
            lib.compute_l2_norm_f64_accum.restype = ctypes.c_double
            
        if hasattr(lib, 'compute_hamming_weight'):
            lib.compute_hamming_weight.argtypes = [ctypes.POINTER(ctypes.c_uint64), ctypes.c_int]
            lib.compute_hamming_weight.restype = ctypes.c_uint64

        if hasattr(lib, 'apply_cayley_smw_retraction_f32'):
            lib.apply_cayley_smw_retraction_f32.argtypes = [
                ctypes.POINTER(ctypes.c_float),
                ctypes.POINTER(ctypes.c_float),
                ctypes.POINTER(ctypes.c_float),
                ctypes.c_float,
                ctypes.c_int
            ]
            lib.apply_cayley_smw_retraction_f32.restype = None
            
        if hasattr(lib, 'generate_random_unit_vector_f32'):
            lib.generate_random_unit_vector_f32.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.c_int, ctypes.c_uint64]
            lib.generate_random_unit_vector_f32.restype = None
            
        return BackendInfo("cpp_cpu", True, str(lib_path), lib)
    except Exception:
        return BackendInfo("cpp_cpu", False)

def load_rust_backend() -> BackendInfo:
    ext = ".dll" if platform.system() == "Windows" else ".so"
    lib_path = Path(__file__).parent / f"polydim_rust_v735{ext}"
    if not lib_path.exists():
        return BackendInfo("rust_cpu", False)
        
    try:
        lib = ctypes.CDLL(str(lib_path))
        if hasattr(lib, 'check_l2_norm_f32'):
            lib.check_l2_norm_f32.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.c_size_t]
            lib.check_l2_norm_f32.restype = ctypes.c_double
        
        if hasattr(lib, 'check_hamming_weight'):
            lib.check_hamming_weight.argtypes = [ctypes.POINTER(ctypes.c_uint64), ctypes.c_size_t]
            lib.check_hamming_weight.restype = ctypes.c_int64
            
        if hasattr(lib, 'check_pairwise_inner_products'):
            lib.check_pairwise_inner_products.argtypes = [
                ctypes.POINTER(ctypes.c_float), 
                ctypes.POINTER(ctypes.c_float), 
                ctypes.c_size_t
            ]
            lib.check_pairwise_inner_products.restype = ctypes.c_double
            
        if hasattr(lib, 'check_hamming_distance'):
            lib.check_hamming_distance.argtypes = [
                ctypes.POINTER(ctypes.c_uint64), 
                ctypes.POINTER(ctypes.c_uint64), 
                ctypes.c_size_t
            ]
            lib.check_hamming_distance.restype = ctypes.c_int64
            
        return BackendInfo("rust_cpu", True, str(lib_path), lib)
    except Exception:
        return BackendInfo("rust_cpu", False)

def load_triton_backend() -> BackendInfo:
    try:
        import polydim_triton_kernel_v733
        if getattr(polydim_triton_kernel_v733, 'TRITON_AVAILABLE', False):
            return BackendInfo("triton_gpu", True, lib_obj=polydim_triton_kernel_v733)
    except ImportError:
        pass
    return BackendInfo("triton_gpu", False)

# ============================================================
# 3. BSC ISOMETRY
# ============================================================
def generate_permutation_lut(d_blocks: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    return rng.permutation(d_blocks).astype(np.uint64)

def generate_fixed_mask(d_blocks: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    uint64_max = np.iinfo(np.uint64).max
    return rng.integers(0, uint64_max, size=d_blocks, dtype=np.uint64, endpoint=True)

def run_bsc_isometry_numpy(tensor: np.ndarray, perm_lut: np.ndarray, fixed_mask: np.ndarray, iterations: int) -> np.ndarray:
    for _ in range(iterations):
        tensor = tensor[perm_lut] ^ fixed_mask
    return tensor

def run_bsc_isometry_cpp(tensor: np.ndarray, perm_lut: np.ndarray, fixed_mask: np.ndarray, iterations: int, lib: Any) -> np.ndarray:
    if not hasattr(lib, 'bsc_isometry_single_step') or not hasattr(lib, 'precompute_isometry_composition'):
        raise NotImplementedError("bsc_isometry functions missing in C++ backend")
    
    tensor_p = tensor.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64))
    perm_p = perm_lut.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64))
    mask_p = fixed_mask.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64))
    d_blocks = len(tensor)
    
    # O(n) Precompute composition T^k
    perm_out = np.empty_like(perm_lut)
    mask_out = np.empty_like(fixed_mask)
    perm_out_p = perm_out.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64))
    mask_out_p = mask_out.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64))
    
    lib.precompute_isometry_composition(perm_p, mask_p, perm_out_p, mask_out_p, d_blocks, iterations)
    
    # Execute exactly once
    lib.bsc_isometry_single_step(tensor_p, perm_out_p, mask_out_p, d_blocks)
        
    return tensor

# ============================================================
# 4. HOUSEHOLDER PATHWAY
# ============================================================
def run_householder_numpy(tensor: np.ndarray, iterations: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    d = len(tensor)
    for _ in range(iterations):
        v = rng.standard_normal(d).astype(np.float32)
        v_norm = np.linalg.norm(v.astype(np.float64))
        v = (v.astype(np.float64) / v_norm).astype(np.float32)
        
        dot = np.float64(np.dot(tensor.astype(np.float64), v.astype(np.float64)))
        tensor -= np.float32(2.0 * dot) * v
    return tensor

def run_householder_cpp(tensor: np.ndarray, iterations: int, seed: int, lib: Any) -> np.ndarray:
    if not hasattr(lib, 'householder_single_step_f32') or not hasattr(lib, 'generate_random_unit_vector_f32'):
        raise NotImplementedError("Householder functions missing in C++ backend")
        
    d = len(tensor)
    tensor_p = tensor.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
    
    v = np.empty(d, dtype=np.float32)
    v_p = v.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
    
    for i in range(iterations):
        step_seed = seed + i
        lib.generate_random_unit_vector_f32(v_p, d, ctypes.c_uint64(step_seed))
        lib.householder_single_step_f32(tensor_p, v_p, d)
        
    return tensor

def compute_l2_norm(tensor: np.ndarray) -> float:
    return np.linalg.norm(tensor.astype(np.float64))

def compute_hamming_weight(tensor: np.ndarray) -> int:
    return np.unpackbits(tensor.view(np.uint8)).sum()

# ============================================================
# 5. BENCHMARK HARNESS
# ============================================================
@dataclass
class BenchmarkResult:
    backend: str
    pathway: str
    D: int
    iterations: int
    run_index: int
    seed: int
    wall_time_s: float
    l2_norm_final: float
    l2_drift: float
    hamming_weight: Optional[int]

def run_benchmark(backend_info: BackendInfo, pathway: str, n_runs: int, d: int, iterations: int, seed_base: int, rust_backend: BackendInfo = None) -> List[BenchmarkResult]:
    results = []
    
    for run_index in range(n_runs):
        seed = seed_base + run_index
        rng = np.random.default_rng(seed)
        
        if pathway == "householder":
            tensor = rng.standard_normal(d).astype(np.float32)
            initial_norm = compute_l2_norm(tensor)
            
            t0 = time.perf_counter()
            if backend_info.name == "numpy_cpu":
                tensor_out = run_householder_numpy(tensor, iterations, seed)
            elif backend_info.name == "cpp_cpu":
                tensor_out = run_householder_cpp(tensor, iterations, seed, backend_info.lib_obj)
            else:
                raise NotImplementedError(f"Pathway {pathway} not implemented for {backend_info.name}")
            t1 = time.perf_counter()
            
            final_norm = compute_l2_norm(tensor_out)
            drift = abs(final_norm - initial_norm)
            hw = None
            
            # GHOST ORCHESTRATOR VALIDATION (RUST)
            if rust_backend and rust_backend.available and backend_info.name == "cpp_cpu":
                tensor_p = tensor_out.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
                rust_norm = rust_backend.lib_obj.check_l2_norm_f32(tensor_p, ctypes.c_size_t(d))
                rust_drift = abs(rust_norm - initial_norm)
                if abs(rust_drift - drift) > 1e-6:
                    print(f"  [RUST VALIDATION WARNING] C++ drift: {drift}, Rust drift: {rust_drift}")
            
        elif pathway == "bsc":
            # D bits packed into uint64 words: each word holds 64 bits
            d_blocks = d // 64 + (1 if d % 64 != 0 else 0)
            uint64_max = np.iinfo(np.uint64).max
            tensor = rng.integers(0, uint64_max, size=d_blocks, dtype=np.uint64, endpoint=True)
            
            perm_lut = generate_permutation_lut(d_blocks, seed)
            fixed_mask = generate_fixed_mask(d_blocks, seed)
            
            t0 = time.perf_counter()
            if backend_info.name == "numpy_cpu":
                tensor_out = run_bsc_isometry_numpy(tensor, perm_lut, fixed_mask, iterations)
            elif backend_info.name == "cpp_cpu":
                tensor_out = run_bsc_isometry_cpp(tensor, perm_lut, fixed_mask, iterations, backend_info.lib_obj)
            else:
                raise NotImplementedError(f"Pathway {pathway} not implemented for {backend_info.name}")
            t1 = time.perf_counter()
            
            final_norm = 0.0
            drift = 0.0
            hw = int(compute_hamming_weight(tensor_out))
            
            # GHOST ORCHESTRATOR VALIDATION (RUST)
            if rust_backend and rust_backend.available and backend_info.name == "cpp_cpu":
                tensor_p = tensor_out.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64))
                rust_hw = rust_backend.lib_obj.check_hamming_weight(tensor_p, ctypes.c_size_t(d_blocks))
                if rust_hw != hw:
                    print(f"  [RUST VALIDATION WARNING] C++ HW: {hw}, Rust HW: {rust_hw}")
            
            final_norm = 0.0
            drift = 0.0
            hw = int(compute_hamming_weight(tensor_out))
            
        results.append(BenchmarkResult(
            backend=backend_info.name,
            pathway=pathway,
            D=d,
            iterations=iterations,
            run_index=run_index,
            seed=seed,
            wall_time_s=t1 - t0,
            l2_norm_final=final_norm,
            l2_drift=drift,
            hamming_weight=hw
        ))
        
    return results

def compute_statistics(results: List[BenchmarkResult]) -> Dict[str, Any]:
    if not results:
        return {}
        
    times = [r.wall_time_s for r in results]
    drifts = [r.l2_drift for r in results]
    
    return {
        "wall_time_s": {
            "median": float(np.median(times)),
            "iqr": float(np.percentile(times, 75) - np.percentile(times, 25)),
            "min": float(np.min(times)),
            "max": float(np.max(times))
        },
        "l2_drift": {
            "median": float(np.median(drifts)),
            "iqr": float(np.percentile(drifts, 75) - np.percentile(drifts, 25)),
            "min": float(np.min(drifts)),
            "max": float(np.max(drifts))
        }
    }

# ============================================================
# 6. MAIN
# ============================================================
def main():
    print("[SECTION] HARDWARE INTERROGATION")
    hw_info = get_hardware_info()
    print(json.dumps(asdict(hw_info), indent=2))
    
    print("\n[SECTION] BACKEND REGISTRY")
    backends = {
        "numpy_cpu": BackendInfo("numpy_cpu", True),
        "cpp_cpu": load_cpp_backend(),
        "rust_cpu": load_rust_backend(),
        "triton_gpu": load_triton_backend()
    }
    
    for name, b in backends.items():
        print(f"Backend '{name}': {'AVAILABLE' if b.available else 'MISSING'}")
        if b.lib_path:
            print(f"  Path: {b.lib_path}")
            
    print(f"\n[SECTION] RUNNING BENCHMARKS (D={D}, ITERATIONS={ITERATIONS}, N_RUNS={N_RUNS})")
    
    all_results = []
    
    for b_name in ["numpy_cpu", "cpp_cpu"]:
        backend = backends[b_name]
        if not backend.available:
            continue
            
        for pathway in ["householder", "bsc"]:
            print(f"Running {b_name} - {pathway}...")
            try:
                res = run_benchmark(backend, pathway, N_RUNS, D, ITERATIONS, SEED_BASE, backends["rust_cpu"])
                all_results.extend(res)
                stats = compute_statistics(res)
                print(f"  Median Time: {stats['wall_time_s']['median']:.4f} s (IQR: {stats['wall_time_s']['iqr']:.4f})")
                if pathway == "householder":
                    print(f"  Median Drift: {stats['l2_drift']['median']:.4e} (IQR: {stats['l2_drift']['iqr']:.4e})")
            except NotImplementedError as e:
                print(f"  Skipped: {e}")
            except Exception as e:
                print(f"  Error: {e}")
                
    print("\n[SECTION] SAVING RESULTS")
    out_dict = {
        "hardware": asdict(hw_info),
        "backends": {k: {"available": v.available} for k, v in backends.items()},
        "parameters": {
            "D": D,
            "ITERATIONS": ITERATIONS,
            "N_RUNS": N_RUNS,
            "SEED_BASE": SEED_BASE
        },
        "results": [asdict(r) for r in all_results]
    }
    
    out_path = Path(__file__).parent / "raw_results.json"
    with open(out_path, "w") as f:
        json.dump(out_dict, f, indent=2)
    print(f"Saved to {out_path}")
    
    if backends["rust_cpu"].available:
        print("\n[SECTION] RUST VALIDATORS")
        print("Rust validators available (validation tests can be run explicitly using ctypes integration).")

if __name__ == '__main__':
    main()
