import ctypes
from ctypes import POINTER, c_float, c_size_t, c_int, c_uint64, c_double, c_int64
import numpy as np
import time
import sys
import multiprocessing
from multiprocessing import shared_memory
from pathlib import Path
import platform

D = 10_000_000  # 10 Million dimensions -> 40 MB tensor (f32)

def load_cpp():
    ext = ".dll" if platform.system() == "Windows" else ".so"
    lib_path = Path(__file__).parent / f"polydim_cpp_v735{ext}"
    lib = ctypes.CDLL(str(lib_path))
    lib.generate_random_unit_vector_f32.argtypes = [POINTER(c_float), c_int, c_uint64]
    lib.generate_random_unit_vector_f32.restype = None
    lib.compute_l2_norm_f64_accum.argtypes = [POINTER(c_float), c_int]
    lib.compute_l2_norm_f64_accum.restype = c_double
    return lib

def load_rust():
    ext = ".dll" if platform.system() == "Windows" else ".so"
    lib_path = Path(__file__).parent / f"polydim_rust_v735{ext}"
    lib = ctypes.CDLL(str(lib_path))
    lib.check_l2_norm_f32.argtypes = [POINTER(c_float), c_size_t]
    lib.check_l2_norm_f32.restype = c_double
    return lib

def agent_a_worker():
    print("[AGENTE A] Iniciando cognitividad en S^(D-1)...")
    cpp_lib = load_cpp()
    
    # 1. Crear Shared Memory PMTP
    shm_size = D * 4 # 4 bytes per float32
    t0 = time.perf_counter()
    shm = shared_memory.SharedMemory(create=True, size=shm_size)
    
    # 2. Mapear tensor a la memoria compartida
    tensor_a = np.ndarray((D,), dtype=np.float32, buffer=shm.buf)
    ptr_a = tensor_a.ctypes.data_as(POINTER(c_float))
    
    # 3. Generar vector unitario en C++
    seed = 42
    cpp_lib.generate_random_unit_vector_f32(ptr_a, D, seed)
    
    # 4. Calcular norma de control
    l2_a = cpp_lib.compute_l2_norm_f64_accum(ptr_a, D)
    t1 = time.perf_counter()
    
    print(f"[AGENTE A] PMTP SHM creado: {shm_size / (1024**2):.2f} MB en {t1-t0:.4f}s")
    print(f"[AGENTE A] Tensor L2 Norm: {l2_a:.15f}")
    print(f"[AGENTE A] Token 1D colapsado (Dirección PMTP): '{shm.name}'")
    
    # 5. Lanzar Agente B pasandole SOLO el nombre (token)
    p = multiprocessing.Process(target=agent_b_worker, args=(shm.name, l2_a))
    p.start()
    p.join()
    
    # 6. Limpieza
    shm.close()
    shm.unlink()

def agent_b_worker(shm_name, control_l2):
    t0 = time.perf_counter()
    
    # 1. Agente B se engancha a la memoria (Zero-Copy)
    shm = shared_memory.SharedMemory(name=shm_name)
    tensor_b = np.ndarray((D,), dtype=np.float32, buffer=shm.buf)
    ptr_b = tensor_b.ctypes.data_as(POINTER(c_float))
    
    t1 = time.perf_counter()
    
    print(f"[AGENTE B] Tensor de {D*4 / (1024**2):.2f} MB recuperado en {t1-t0:.6f}s (Cero colapso a 1D, cero JSON)")
    
    # 2. Auditar con Rust
    rust_lib = load_rust()
    t2 = time.perf_counter()
    l2_b = rust_lib.check_l2_norm_f32(ptr_b, D)
    t3 = time.perf_counter()
    
    print(f"[AGENTE B] Rust Veredicto Topológico: L2 = {l2_b:.15f} (Auditado en {t3-t2:.4f}s)")
    
    drift = abs(l2_b - control_l2)
    if drift < 1e-6:
        print(f"[AGENTE B] MATCH ABSOLUTO. PMTP IPC ZERO-COPY CERTIFICADO. Drift: {drift:.4e}")
    else:
        print(f"[AGENTE B] ERROR FATAL. Corrupción de memoria o pérdida dimensional. Drift: {drift:.4e}")
        
    shm.close()

if __name__ == '__main__':
    # Para Windows multiprocessing
    multiprocessing.freeze_support()
    agent_a_worker()
