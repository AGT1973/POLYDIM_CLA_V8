// =====================================================================
// POLYDIM V733 INDUSTRIAL - C++ KERNEL
// =====================================================================
// Compiled as shared library: cl /LD /O2 /openmp /fp:precise
// All functions extern "C" for FFI via Python ctypes
// =====================================================================

#include <cstdint>
#include <cmath>
#include <cstring>
#include <omp.h>
#include <vector>
#include <algorithm>

#ifdef _MSC_VER
#include <intrin.h>
#define POPCOUNT64 __popcnt64
#else
#define POPCOUNT64 __builtin_popcountll
#endif

// =====================================================================
// Philox4x32 PRNG (Stateless Counter-Based)
// =====================================================================
inline void philox4x32_bump(uint32_t ctr[4], uint32_t key[2]) {
    const uint32_t PHILOX_M4x32_0 = 0xD2511F53;
    const uint32_t PHILOX_M4x32_1 = 0xCD9E8D57;
    for (int i = 0; i < 10; ++i) {
        uint32_t hi0, lo0, hi1, lo1;
        // Multiply
        uint64_t prod0 = (uint64_t)ctr[0] * PHILOX_M4x32_0;
        hi0 = (uint32_t)(prod0 >> 32);
        lo0 = (uint32_t)prod0;
        
        uint64_t prod1 = (uint64_t)ctr[2] * PHILOX_M4x32_1;
        hi1 = (uint32_t)(prod1 >> 32);
        lo1 = (uint32_t)prod1;
        
        uint32_t v0 = hi1 ^ ctr[1] ^ key[0];
        uint32_t v1 = lo1;
        uint32_t v2 = hi0 ^ ctr[3] ^ key[1];
        uint32_t v3 = lo0;
        
        ctr[0] = v0; ctr[1] = v1; ctr[2] = v2; ctr[3] = v3;
        key[0] += 0x9E3779B9;
        key[1] += 0xBB67AE85;
    }
}

inline uint64_t philox_random_u64(uint32_t base_seed, uint32_t tid, uint32_t idx) {
    uint32_t ctr[4] = { idx, tid, 0, 0 };
    uint32_t key[2] = { base_seed, base_seed ^ 0x9E3779B9 };
    philox4x32_bump(ctr, key);
    return ((uint64_t)ctr[0] << 32) | ctr[1];
}

#ifdef _WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT __attribute__((visibility("default")))
#endif

extern "C" {

EXPORT void bsc_xor_single_step(uint64_t* tensor, int d_blocks, uint64_t seed) {
    if (!tensor || d_blocks <= 0) return;

    #pragma omp parallel for
    for (int i = 0; i < d_blocks; ++i) {
        // Counter based PRNG: deterministic irrespective of thread count
        tensor[i] ^= philox_random_u64((uint32_t)seed, 0, (uint32_t)i);
    }
}

EXPORT void bsc_isometry_single_step(uint64_t* tensor, const uint64_t* permutation_lut, const uint64_t* fixed_mask, int d_blocks) {
    if (!tensor || !permutation_lut || !fixed_mask || d_blocks <= 0) return;

    uint64_t* temp = new uint64_t[d_blocks];

    #pragma omp parallel for
    for (int i = 0; i < d_blocks; ++i) {
        uint64_t p_idx = permutation_lut[i];
        if (p_idx < (uint64_t)d_blocks) {
            temp[i] = tensor[p_idx] ^ fixed_mask[i];
        } else {
            // Abort instead of silent fallback for isometric safety
            // In a real panic we would exit, here we write an invalid marker
            temp[i] = 0xDEADBEEFDEADBEEF; 
        }
    }

    std::memcpy(tensor, temp, d_blocks * sizeof(uint64_t));
    delete[] temp;
}

// Composición T^k O(n log k) via binary exponentiation o simplemente O(k*n) en C++ 
// para precalcular y evitar 50 llamadas en Python.
EXPORT void precompute_isometry_composition(const uint64_t* P_in, const uint64_t* M_in, uint64_t* P_out, uint64_t* M_out, int D, int k) {
    if (!P_in || !M_in || !P_out || !M_out || D <= 0 || k <= 0) return;
    
    std::vector<uint64_t> P_current(P_in, P_in + D);
    std::vector<uint64_t> M_current(M_in, M_in + D);
    std::vector<uint64_t> P_next(D);
    std::vector<uint64_t> M_next(D);

    for (int step = 1; step < k; ++step) {
        #pragma omp parallel for
        for (int i = 0; i < D; ++i) {
            uint64_t nxt = P_current[i];
            if (nxt < (uint64_t)D) {
                P_next[i] = P_in[nxt];
                M_next[i] = M_current[i] ^ M_in[nxt];
            } else {
                P_next[i] = nxt;
                M_next[i] = M_current[i];
            }
        }
        std::swap(P_current, P_next);
        std::swap(M_current, M_next);
    }
    std::memcpy(P_out, P_current.data(), D * sizeof(uint64_t));
    std::memcpy(M_out, M_current.data(), D * sizeof(uint64_t));
}

#if defined(__x86_64__) || defined(_M_X64)
#include <xmmintrin.h>
#include <pmmintrin.h>
#endif

EXPORT void householder_single_step_f32(float* tensor, const float* v, int D) {
    if (!tensor || !v || D <= 0) return;

#if defined(__x86_64__) || defined(_M_X64)
    _MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);
    _MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_ON);
#endif

    double dot_product = 0.0;
    
    // For FMA and Householder, accumulation should use KBN or exact tree if required.
    // Standard reduction is OK here if not strict, but let's use a stable one.
    #pragma omp parallel for reduction(+:dot_product)
    for (int i = 0; i < D; ++i) {
        dot_product = std::fma((double)tensor[i], (double)v[i], dot_product);
    }

    #pragma omp parallel for
    for (int i = 0; i < D; ++i) {
        tensor[i] = (float)std::fma(-2.0 * dot_product, (double)v[i], (double)tensor[i]);
    }
}

// Fixed Tree KBN: deterministic bit-exact L2 Norm (Cache-line padded)
struct alignas(64) KBNState {
    double sum;
    double comp;
};

EXPORT double compute_l2_norm_f64_accum(const float* tensor, int D) {
    if (!tensor || D <= 0) return 0.0;
    
    const int CHUNK_SIZE = 4096;
    int num_chunks = (D + CHUNK_SIZE - 1) / CHUNK_SIZE;
    std::vector<KBNState> chunks(num_chunks, {0.0, 0.0});
    
    #pragma omp parallel for
    for (int c = 0; c < num_chunks; ++c) {
        int start = c * CHUNK_SIZE;
        int end = std::min(start + CHUNK_SIZE, D);
        double sum = 0.0;
        double comp = 0.0;
        for (int i = start; i < end; ++i) {
            double val = (double)tensor[i];
            double y = (val * val) - comp;
            double t = sum + y;
            comp = (t - sum) - y;
            sum = t;
        }
        chunks[c].sum = sum;
        chunks[c].comp = comp;
    }
    
    // Deterministic sequential reduction of chunks (small tree)
    double final_sum = 0.0;
    double final_comp = 0.0;
    for (int c = 0; c < num_chunks; ++c) {
        double y = chunks[c].sum - final_comp;
        double t = final_sum + y;
        final_comp = (t - final_sum) - y;
        final_sum = t;
    }
    
    return std::sqrt(final_sum);
}

EXPORT uint64_t compute_hamming_weight(const uint64_t* tensor, int d_blocks) {
    if (!tensor || d_blocks <= 0) return 0;
    
    uint64_t total_weight = 0;
    
    #pragma omp parallel for reduction(+:total_weight)
    for (int i = 0; i < d_blocks; ++i) {
        total_weight += POPCOUNT64(tensor[i]);
    }
    
    return total_weight;
}

EXPORT void generate_random_unit_vector_f32(float* out, int D, uint64_t seed) {
    if (!out || D <= 0) return;

    #pragma omp parallel for
    for (int i = 0; i < D; i += 2) {
        // Mezzadri strict RNG with Philox
        uint64_t r1 = philox_random_u64((uint32_t)seed, 1, (uint32_t)i);
        uint64_t r2 = philox_random_u64((uint32_t)seed, 2, (uint32_t)i);
        
        double u1 = (r1 >> 11) * 0x1.0p-53;
        double u2 = (r2 >> 11) * 0x1.0p-53;
        
        if (u1 <= 0.0) u1 = 1e-15;
        
        double mag = std::sqrt(-2.0 * std::log(u1));
        double z0 = mag * std::cos(2.0 * 3.14159265358979323846 * u2);
        double z1 = mag * std::sin(2.0 * 3.14159265358979323846 * u2);

        out[i] = (float)z0;
        if (i + 1 < D) {
            out[i + 1] = (float)z1;
        }
    }

    double norm = compute_l2_norm_f64_accum(out, D);
    if (norm > 0.0) {
        #pragma omp parallel for
        for (int i = 0; i < D; ++i) {
            out[i] = (float)((double)out[i] / norm);
        }
    }
}

} // extern "C"

