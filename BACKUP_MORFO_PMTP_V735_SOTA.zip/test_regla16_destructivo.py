"""
POLYDIM V732 INDUSTRIAL — REGLA 16: ATAQUE DESTRUCTIVO ADVERSARIAL
===================================================================
Ataca los kernels C++ y Rust compilados vía FFI con inputs degenerados:
  - NaN, Inf, -Inf, subnormales
  - Vector cero
  - D=1 (mínimo), D=10M (asintótico)
  - Bit patterns extremos (all-zeros, all-ones uint64)
  - Punteros NULL (simulados via ctypes)
  - Verificación cruzada NumPy vs C++ vs Rust
Regla 16a: Código asumido ROTO hasta prueba empírica.
Regla 16b: Degenerate inputs obligatorios.
Regla 16c: Cero veredictos sin ejecución.
"""
import ctypes
import numpy as np
import platform
import sys
import time
import traceback
from pathlib import Path

# ============================================================
# LOAD NATIVE LIBRARIES
# ============================================================
EXT = ".dll" if platform.system() == "Windows" else ".so"
BASE = Path(__file__).parent

def load_cpp():
    p = BASE / f"polydim_cpp_v732{EXT}"
    if not p.exists():
        return None
    lib = ctypes.CDLL(str(p))
    lib.householder_single_step_f32.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float), ctypes.c_int]
    lib.householder_single_step_f32.restype = None
    lib.compute_l2_norm_f64_accum.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.c_int]
    lib.compute_l2_norm_f64_accum.restype = ctypes.c_double
    lib.compute_hamming_weight.argtypes = [ctypes.POINTER(ctypes.c_uint64), ctypes.c_int]
    lib.compute_hamming_weight.restype = ctypes.c_uint64
    lib.generate_random_unit_vector_f32.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.c_int, ctypes.c_uint64]
    lib.generate_random_unit_vector_f32.restype = None
    lib.bsc_isometry_single_step.argtypes = [ctypes.POINTER(ctypes.c_uint64), ctypes.POINTER(ctypes.c_uint64), ctypes.POINTER(ctypes.c_uint64), ctypes.c_int]
    lib.bsc_isometry_single_step.restype = None
    return lib

def load_rust():
    p = BASE / f"polydim_rust_v732{EXT}"
    if not p.exists():
        return None
    lib = ctypes.CDLL(str(p))
    lib.check_l2_norm_f32.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.c_size_t]
    lib.check_l2_norm_f32.restype = ctypes.c_double
    lib.check_hamming_weight.argtypes = [ctypes.POINTER(ctypes.c_uint64), ctypes.c_size_t]
    lib.check_hamming_weight.restype = ctypes.c_int64
    lib.check_pairwise_inner_products.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float), ctypes.c_size_t]
    lib.check_pairwise_inner_products.restype = ctypes.c_double
    lib.check_hamming_distance.argtypes = [ctypes.POINTER(ctypes.c_uint64), ctypes.POINTER(ctypes.c_uint64), ctypes.c_size_t]
    lib.check_hamming_distance.restype = ctypes.c_int64
    return lib

# ============================================================
# TEST INFRASTRUCTURE
# ============================================================
PASS_COUNT = 0
FAIL_COUNT = 0
RESULTS = []

def report(test_name, passed, detail=""):
    global PASS_COUNT, FAIL_COUNT
    status = "PASS" if passed else "FAIL"
    if passed:
        PASS_COUNT += 1
    else:
        FAIL_COUNT += 1
    line = f"[{status}] {test_name}"
    if detail:
        line += f" | {detail}"
    print(line)
    RESULTS.append({"test": test_name, "status": status, "detail": detail})

# ============================================================
# HOUND 1: NUMERICAL PRECISION ATTACKS
# ============================================================
def hound_numerical(cpp, rust):
    print("\n" + "="*60)
    print("HOUND 1: NUMERICAL PRECISION & DEGENERATE INPUTS")
    print("="*60)

    # --- NaN injection ---
    t = np.array([np.nan, 1.0, 2.0, 3.0], dtype=np.float32)
    v = np.array([0.5, 0.5, 0.5, 0.5], dtype=np.float32)
    v /= np.linalg.norm(v)
    t_copy = t.copy()
    cpp.householder_single_step_f32(
        t_copy.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        v.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        4
    )
    has_nan = np.any(np.isnan(t_copy))
    report("NaN propagation (Householder C++)", has_nan, f"NaN propagates correctly: {has_nan}")

    # --- Inf injection ---
    t = np.array([np.inf, 1.0, -np.inf, 0.0], dtype=np.float32)
    norm = cpp.compute_l2_norm_f64_accum(
        t.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), 4
    )
    report("Inf norm (C++ f64 accum)", np.isinf(norm) or np.isnan(norm), f"norm={norm}")

    if rust:
        norm_rust = rust.check_l2_norm_f32(
            t.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), 4
        )
        report("Inf norm (Rust f64 accum)", np.isinf(norm_rust) or np.isnan(norm_rust), f"norm={norm_rust}")

    # --- Subnormal floats ---
    smallest = np.finfo(np.float32).tiny  # ~1.17e-38
    t = np.full(1000, smallest * 0.01, dtype=np.float32)  # subnormal territory
    norm_sub = cpp.compute_l2_norm_f64_accum(
        t.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), 1000
    )
    report("Subnormal f32 norm (C++)", norm_sub >= 0.0, f"norm={norm_sub:.6e}")

    # --- Zero vector ---
    t = np.zeros(1000, dtype=np.float32)
    v = np.random.randn(1000).astype(np.float32)
    v /= np.linalg.norm(v)
    cpp.householder_single_step_f32(
        t.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        v.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        1000
    )
    report("Zero vector stays zero (C++)", np.allclose(t, 0.0), f"max_val={np.max(np.abs(t))}")

    # --- D=1 minimal dimension ---
    t = np.array([3.14], dtype=np.float32)
    v = np.array([1.0], dtype=np.float32)
    orig_val = t[0]
    cpp.householder_single_step_f32(
        t.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        v.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        1
    )
    # H*x = x - 2*(x.v)*v = 3.14 - 2*3.14*1 = -3.14
    report("D=1 Householder reflection (C++)", np.isclose(t[0], -orig_val, atol=1e-5),
           f"expected={-orig_val:.4f}, got={t[0]:.4f}")

    # --- Cross-validation C++ vs Rust norms ---
    if rust:
        rng = np.random.default_rng(777)
        t = rng.standard_normal(10000).astype(np.float32)
        norm_cpp = cpp.compute_l2_norm_f64_accum(
            t.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), 10000
        )
        norm_rust = rust.check_l2_norm_f32(
            t.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), 10000
        )
        norm_numpy = float(np.linalg.norm(t.astype(np.float64)))
        max_diff = max(abs(norm_cpp - norm_numpy), abs(norm_rust - norm_numpy))
        report("Cross-validation C++ vs Rust vs NumPy (D=10k)",
               max_diff < 1e-10,
               f"C++={norm_cpp:.12f} Rust={norm_rust:.12f} NumPy={norm_numpy:.12f} maxdiff={max_diff:.2e}")

# ============================================================
# HOUND 2: FFI BOUNDARY ATTACKS
# ============================================================
def hound_ffi(cpp, rust):
    print("\n" + "="*60)
    print("HOUND 2: FFI BOUNDARY & MEMORY SAFETY")
    print("="*60)

    # --- D=0 ---
    t = np.array([], dtype=np.float32)
    norm = cpp.compute_l2_norm_f64_accum(
        t.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), 0
    )
    report("D=0 C++ norm returns 0", norm == 0.0, f"norm={norm}")

    if rust:
        norm_r = rust.check_l2_norm_f32(
            t.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), 0
        )
        report("D=0 Rust norm returns 0", norm_r == 0.0, f"norm={norm_r}")

    # --- NULL pointer simulation (Rust) ---
    if rust:
        null_ptr = ctypes.POINTER(ctypes.c_float)()
        norm_null = rust.check_l2_norm_f32(null_ptr, 100)
        report("NULL pointer Rust check_l2_norm_f32 returns -1.0",
               norm_null == -1.0, f"returned={norm_null}")

        null_u64 = ctypes.POINTER(ctypes.c_uint64)()
        hw_null = rust.check_hamming_weight(null_u64, 100)
        report("NULL pointer Rust check_hamming_weight returns -1",
               hw_null == -1, f"returned={hw_null}")

    # --- Negative D to C++ (should be handled gracefully) ---
    t = np.ones(10, dtype=np.float32)
    norm_neg = cpp.compute_l2_norm_f64_accum(
        t.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), -5
    )
    report("Negative D C++ norm returns 0", norm_neg == 0.0, f"norm={norm_neg}")

    # --- Pairwise inner product cross-check (Rust) ---
    if rust:
        a = np.array([1.0, 0.0, 0.0], dtype=np.float32)
        b = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        ip = rust.check_pairwise_inner_products(
            a.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            b.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            3
        )
        report("Orthogonal vectors inner product = 0 (Rust)", abs(ip) < 1e-10, f"ip={ip}")

        c = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        d = np.array([4.0, 5.0, 6.0], dtype=np.float32)
        ip2 = rust.check_pairwise_inner_products(
            c.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            d.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            3
        )
        expected = float(np.dot(c.astype(np.float64), d.astype(np.float64)))
        report("Inner product accuracy (Rust f64)", abs(ip2 - expected) < 1e-10,
               f"rust={ip2}, expected={expected}")

# ============================================================
# HOUND 3: ISOMETRY PRESERVATION UNDER STRESS
# ============================================================
def hound_isometry(cpp, rust):
    print("\n" + "="*60)
    print("HOUND 3: ISOMETRY PRESERVATION (ASYMPTOTIC D=10^6)")
    print("="*60)

    D = 1_000_000
    rng = np.random.default_rng(999)

    # --- Householder: 50 reflections preserve norm ---
    tensor = rng.standard_normal(D).astype(np.float32)
    tensor /= np.linalg.norm(tensor.astype(np.float64)).astype(np.float32)
    initial_norm = float(np.linalg.norm(tensor.astype(np.float64)))

    v_buf = np.empty(D, dtype=np.float32)
    t0 = time.perf_counter()
    for i in range(50):
        cpp.generate_random_unit_vector_f32(
            v_buf.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            D, ctypes.c_uint64(42 + i)
        )
        cpp.householder_single_step_f32(
            tensor.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            v_buf.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            D
        )
    t1 = time.perf_counter()

    final_norm_cpp = cpp.compute_l2_norm_f64_accum(
        tensor.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), D
    )
    drift = abs(final_norm_cpp - initial_norm)
    report(f"Householder 50 steps D={D} norm preservation (C++)",
           drift < 1e-4,
           f"drift={drift:.6e} time={t1-t0:.2f}s")

    # Cross-check with Rust validator
    if rust:
        final_norm_rust = rust.check_l2_norm_f32(
            tensor.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), D
        )
        diff = abs(final_norm_cpp - final_norm_rust)
        report("C++ vs Rust norm agreement after 50 Householder steps",
               diff < 1e-12,
               f"C++={final_norm_cpp:.12f} Rust={final_norm_rust:.12f} diff={diff:.2e}")

    # --- Pairwise inner product preservation ---
    if rust:
        a = rng.standard_normal(D).astype(np.float32)
        b = rng.standard_normal(D).astype(np.float32)
        ip_before = rust.check_pairwise_inner_products(
            a.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            b.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            D
        )
        # Apply SAME Householder to both
        v = rng.standard_normal(D).astype(np.float32)
        v = (v.astype(np.float64) / np.linalg.norm(v.astype(np.float64))).astype(np.float32)
        for vec in [a, b]:
            cpp.householder_single_step_f32(
                vec.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
                v.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
                D
            )
        ip_after = rust.check_pairwise_inner_products(
            a.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            b.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            D
        )
        ip_drift = abs(ip_after - ip_before)
        report(f"Pairwise inner product preservation D={D} (Z_AI criterion)",
               ip_drift < 1e-2,
               f"before={ip_before:.6f} after={ip_after:.6f} drift={ip_drift:.6e}")

    # --- BSC Hamming distance preservation ---
    d_blocks = D // 64
    a_bsc = rng.integers(0, np.iinfo(np.uint64).max, size=d_blocks, dtype=np.uint64, endpoint=True)
    b_bsc = rng.integers(0, np.iinfo(np.uint64).max, size=d_blocks, dtype=np.uint64, endpoint=True)

    if rust:
        hd_before = rust.check_hamming_distance(
            a_bsc.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)),
            b_bsc.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)),
            d_blocks
        )

    perm = rng.permutation(d_blocks).astype(np.uint64)
    mask = rng.integers(0, np.iinfo(np.uint64).max, size=d_blocks, dtype=np.uint64, endpoint=True)

    # Apply isometry via C++
    cpp.bsc_isometry_single_step(
        a_bsc.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)),
        perm.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)),
        mask.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)),
        d_blocks
    )
    cpp.bsc_isometry_single_step(
        b_bsc.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)),
        perm.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)),
        mask.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)),
        d_blocks
    )

    if rust:
        hd_after = rust.check_hamming_distance(
            a_bsc.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)),
            b_bsc.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)),
            d_blocks
        )
        report(f"BSC Hamming distance preserved D={D} (C++ isometry + Rust validator)",
               hd_before == hd_after,
               f"before={hd_before} after={hd_after}")

    # --- All-ones / All-zeros BSC edge cases ---
    ones = np.full(d_blocks, np.iinfo(np.uint64).max, dtype=np.uint64)
    zeros = np.zeros(d_blocks, dtype=np.uint64)
    if rust:
        hw_ones = rust.check_hamming_weight(
            ones.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)), d_blocks
        )
        hw_zeros = rust.check_hamming_weight(
            zeros.ctypes.data_as(ctypes.POINTER(ctypes.c_uint64)), d_blocks
        )
        report("All-ones Hamming weight (Rust)", hw_ones == d_blocks * 64,
               f"expected={d_blocks*64} got={hw_ones}")
        report("All-zeros Hamming weight (Rust)", hw_zeros == 0,
               f"expected=0 got={hw_zeros}")


# ============================================================
# MAIN
# ============================================================
if __name__ == "__main__":
    print("=" * 60)
    print("POLYDIM V732 — REGLA 16: ATAQUE DESTRUCTIVO ADVERSARIAL")
    print("3 SABUESOS RED TEAM vs KERNELS NATIVOS (C++ + RUST)")
    print("=" * 60)

    cpp = load_cpp()
    rust = load_rust()

    if not cpp:
        print("[FATAL] C++ DLL not found. Cannot proceed.")
        sys.exit(1)
    print(f"[OK] C++ kernel loaded")
    if rust:
        print(f"[OK] Rust kernel loaded")
    else:
        print("[WARN] Rust DLL not found. Partial tests only.")

    hound_numerical(cpp, rust)
    hound_ffi(cpp, rust)
    hound_isometry(cpp, rust)

    print("\n" + "=" * 60)
    print(f"RESULTADO FINAL: {PASS_COUNT} PASS / {FAIL_COUNT} FAIL")
    print("=" * 60)

    if FAIL_COUNT > 0:
        print("[REGLA 16] CÓDIGO NO CERTIFICADO. Fallas detectadas.")
        sys.exit(1)
    else:
        print("[REGLA 16] CÓDIGO CERTIFICADO EMPÍRICAMENTE.")
        sys.exit(0)
