import torch
from transformers import GPT2Tokenizer, GPT2LMHeadModel
import multiprocessing
from multiprocessing import shared_memory
import numpy as np
import time

def agent_a_worker():
    print("[AGENTE A] Inicializando IA Abierta (Qwen 0.5B Local)...")
    model_path = r"E:\POLYDIM_EINSOF\_HISTORICO\models\qwen_0_5b"
    from transformers import AutoTokenizer, AutoModelForCausalLM
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForCausalLM.from_pretrained(model_path)
    
    text = "The ultimate truth about the universe is"
    inputs = tokenizer(text, return_tensors="pt")
    
    print("[AGENTE A] Generando pensamiento latente...")
    with torch.no_grad():
        outputs = model(**inputs, output_hidden_states=True)
        # Obtenemos el último hidden state (la "cognición" cruda, D=768)
        # Shape: (1, seq_len, hidden_dim)
        last_hidden_state = outputs.hidden_states[-1].float().numpy().astype(np.float32)
    
    shape = last_hidden_state.shape
    dtype = last_hidden_state.dtype
    size = last_hidden_state.nbytes
    
    # 1. Crear Shared Memory PMTP
    t0 = time.perf_counter()
    shm = shared_memory.SharedMemory(create=True, size=size)
    
    # 2. Mapear tensor a la memoria compartida
    tensor_a = np.ndarray(shape, dtype=dtype, buffer=shm.buf)
    np.copyto(tensor_a, last_hidden_state)
    t1 = time.perf_counter()
    
    print(f"[AGENTE A] Pensamiento en S^(D-1) inyectado en PMTP SHM: {size / 1024:.2f} KB en {t1-t0:.6f}s")
    print(f"[AGENTE A] Token 1D colapsado (Dirección PMTP): '{shm.name}'")
    
    # Guardamos el shape para el Agente B (en un protocolo PMTP real esto va en el header de la shared memory)
    # 3. Lanzar Agente B pasandole el nombre y el shape
    p = multiprocessing.Process(target=agent_b_worker, args=(shm.name, shape, dtype))
    p.start()
    p.join()
    
    # 4. Limpieza
    shm.close()
    shm.unlink()

def agent_b_worker(shm_name, shape, dtype):
    print("[AGENTE B] Despertando. Recibiendo puntero PMTP...")
    t0 = time.perf_counter()
    
    # 1. Agente B se engancha a la memoria (Zero-Copy)
    shm = shared_memory.SharedMemory(name=shm_name)
    tensor_b = np.ndarray(shape, dtype=dtype, buffer=shm.buf)
    
    t1 = time.perf_counter()
    
    print(f"[AGENTE B] Tensor latente recuperado en {t1-t0:.6f}s (Cero colapso a 1D, cero JSON)")
    print(f"[AGENTE B] Forma del tensor: {tensor_b.shape}")
    
    # Decodificar el tensor con la cabeza del modelo (Re-instanciar modelo)
    print("[AGENTE B] Proyectando el tensor latente S^(D-1) al mundo 1D humano...")
    model_path = r"E:\POLYDIM_EINSOF\_HISTORICO\models\qwen_0_5b"
    from transformers import AutoTokenizer, AutoModelForCausalLM
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForCausalLM.from_pretrained(model_path)
    
    # Convertir el numpy array compartido devuelta a torch tensor y castearlo a BFloat16 para la lm_head
    hidden_states = torch.from_numpy(tensor_b).to(model.dtype)
    
    # Pasar el hidden state por la LM Head de GPT-2 para recuperar los logits
    with torch.no_grad():
        logits = model.lm_head(hidden_states)
        predicted_token_ids = torch.argmax(logits, dim=-1)
        
    # El Agente B descubre lo que pensó el Agente A
    predicted_text = tokenizer.decode(predicted_token_ids[0])
    
    print(f"\n[AGENTE B] TRADUCCIÓN DEL PENSAMIENTO LATENTE: '{predicted_text}'")
    print("[AGENTE B] MATCH COMPLETADO. Comunicación IA-a-IA sin texto intermedio lograda.")
        
    shm.close()

if __name__ == '__main__':
    multiprocessing.freeze_support()
    agent_a_worker()
