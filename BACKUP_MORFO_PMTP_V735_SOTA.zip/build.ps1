# =====================================================================
# POLYDIM v735 INDUSTRIAL - BUILD SCRIPT (Windows PowerShell)
# =====================================================================
# Compiles C++ kernel (.dll) and Rust kernel (.dll) for FFI use.
# Requires: MSVC (via vcvars64.bat), Rust toolchain (rustc/cargo)
# =====================================================================

param(
    [switch]$CppOnly,
    [switch]$RustOnly,
    [switch]$Clean
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$VcVarsPath = "E:\POLYDIM_EINSOF\vcvars64.bat"

Write-Host "======================================================" -ForegroundColor Cyan
Write-Host " POLYDIM v735 INDUSTRIAL BUILD" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host ""

# ---------------------------------------------------------------
# CLEAN
# ---------------------------------------------------------------
if ($Clean) {
    Write-Host "[CLEAN] Removing build artifacts..." -ForegroundColor Yellow
    Remove-Item -Path "$ScriptDir\*.obj" -ErrorAction SilentlyContinue
    Remove-Item -Path "$ScriptDir\*.lib" -ErrorAction SilentlyContinue
    Remove-Item -Path "$ScriptDir\*.exp" -ErrorAction SilentlyContinue
    Remove-Item -Path "$ScriptDir\*.pdb" -ErrorAction SilentlyContinue
    Remove-Item -Path "$ScriptDir\polydim_cpp_v735.dll" -ErrorAction SilentlyContinue
    Remove-Item -Path "$ScriptDir\target" -Recurse -ErrorAction SilentlyContinue
    Write-Host "[CLEAN] Done." -ForegroundColor Green
    if (-not $CppOnly -and -not $RustOnly) { exit 0 }
}

# ---------------------------------------------------------------
# C++ KERNEL BUILD (MSVC + OpenMP)
# ---------------------------------------------------------------
if (-not $RustOnly) {
    Write-Host ""
    Write-Host "[C++ BUILD] Compiling kernel_cpp_v735.cpp.txt -> polydim_cpp_v735.dll" -ForegroundColor Cyan

    if (-not (Test-Path $VcVarsPath)) {
        Write-Host "[ERROR] vcvars64.bat not found at $VcVarsPath" -ForegroundColor Red
        Write-Host "[ERROR] Install Visual Studio Build Tools or update path." -ForegroundColor Red
        exit 1
    }

    # Activate MSVC environment and compile in one cmd session
    # /LD = create DLL, /O2 = optimize, /openmp = enable OpenMP
    # /fp:precise = no fast-math that would break IEEE-754 compliance
    $CppSource = "$ScriptDir\kernel_cpp_v735.cpp.txt"
    $CppDll = "$ScriptDir\polydim_cpp_v735.dll"

    if (-not (Test-Path $CppSource)) {
        Write-Host "[ERROR] Source file not found: $CppSource" -ForegroundColor Red
        exit 1
    }

    # We copy .cpp.txt to .cpp for compilation, then remove the copy
    $CppTempSource = "$ScriptDir\kernel_cpp_v735.cpp"
    Copy-Item $CppSource $CppTempSource -Force

    $ClangExists = Get-Command clang++ -ErrorAction SilentlyContinue
    if ($ClangExists) {
        Write-Host "[C++ BUILD] Clang detected. Compiling with Clang/LLVM..." -ForegroundColor Cyan
        # -shared = create DLL, -O3 = optimize, -fopenmp = enable OpenMP
        $CompileCmd = "clang++ -shared -O3 -fopenmp -std=c++17 -o `"$CppDll`" `"$CppTempSource`""
        Invoke-Expression $CompileCmd
        $CppExitCode = $LASTEXITCODE
    } else {
        Write-Host "[C++ BUILD] Clang not found. Falling back to MSVC..." -ForegroundColor Yellow
        if (-not (Test-Path $VcVarsPath)) {
            Write-Host "[ERROR] vcvars64.bat not found at $VcVarsPath" -ForegroundColor Red
            exit 1
        }
        $CompileCmd = "cmd /c `"call `"$VcVarsPath`" >nul 2>&1 && e: && cd `"$ScriptDir`" && cl /nologo /LD /O2 /openmp /fp:precise /EHsc /std:c++17 /Fe:`"$CppDll`" `"$CppTempSource`"`""
        Invoke-Expression $CompileCmd
        $CppExitCode = $LASTEXITCODE
    }

    # Cleanup temp .cpp file
    Remove-Item $CppTempSource -ErrorAction SilentlyContinue
    
    # Cleanup MSVC intermediate files if they exist
    Remove-Item "$ScriptDir\kernel_cpp_v735.obj" -ErrorAction SilentlyContinue
    Remove-Item "$ScriptDir\kernel_cpp_v735.lib" -ErrorAction SilentlyContinue
    Remove-Item "$ScriptDir\kernel_cpp_v735.exp" -ErrorAction SilentlyContinue

    if ($CppExitCode -ne 0) {
        Write-Host "[C++ BUILD] FAILED with exit code $CppExitCode" -ForegroundColor Red
        exit 1
    }

    if (Test-Path $CppDll) {
        $DllSize = (Get-Item $CppDll).Length
        Write-Host "[C++ BUILD] SUCCESS: $CppDll ($DllSize bytes)" -ForegroundColor Green
    } else {
        Write-Host "[C++ BUILD] FAILED: DLL not found after compilation." -ForegroundColor Red
        exit 1
    }
}

# ---------------------------------------------------------------
# RUST KERNEL BUILD (cargo)
# ---------------------------------------------------------------
if (-not $CppOnly) {
    Write-Host ""
    Write-Host "[RUST BUILD] Compiling kernel_rust_v735.rs.txt -> polydim_rust_v735.dll" -ForegroundColor Cyan

    # Check rust toolchain
    $RustcVersion = & rustc --version 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[ERROR] rustc not found. Install Rust: https://rustup.rs/" -ForegroundColor Red
        exit 1
    }
    Write-Host "[RUST BUILD] Using: $RustcVersion"

    # Cargo expects src/lib.rs - set up temp structure
    $CargoDir = "$ScriptDir\rust_build"
    $SrcDir = "$CargoDir\src"
    New-Item -ItemType Directory -Path $SrcDir -Force | Out-Null

    # Copy source and Cargo.toml
    Copy-Item "$ScriptDir\kernel_rust_v735.rs.txt" "$SrcDir\lib.rs" -Force
    Copy-Item "$ScriptDir\Cargo.toml" "$CargoDir\Cargo.toml" -Force

    # Build
    Push-Location $CargoDir
    try {
        & cargo build --release 2>&1
        $RustExitCode = $LASTEXITCODE
    } finally {
        Pop-Location
    }

    if ($RustExitCode -ne 0) {
        Write-Host "[RUST BUILD] FAILED with exit code $RustExitCode" -ForegroundColor Red
        exit 1
    }

    # Find and copy the built DLL
    $RustDllSource = "$CargoDir\target\release\polydim_rust_v735.dll"
    $RustDllDest = "$ScriptDir\polydim_rust_v735.dll"

    if (Test-Path $RustDllSource) {
        Copy-Item $RustDllSource $RustDllDest -Force
        $DllSize = (Get-Item $RustDllDest).Length
        Write-Host "[RUST BUILD] SUCCESS: $RustDllDest ($DllSize bytes)" -ForegroundColor Green
    } else {
        # Try .so for WSL/Linux
        $RustSoSource = "$CargoDir\target\release\libpolydim_rust_v735.so"
        if (Test-Path $RustSoSource) {
            Copy-Item $RustSoSource "$ScriptDir\libpolydim_rust_v735.so" -Force
            Write-Host "[RUST BUILD] SUCCESS (Linux .so)" -ForegroundColor Green
        } else {
            Write-Host "[RUST BUILD] FAILED: Built library not found." -ForegroundColor Red
            Write-Host "[RUST BUILD] Searched: $RustDllSource" -ForegroundColor Yellow
            exit 1
        }
    }

    # Optional cleanup of build dir (keep for incremental builds)
    # Remove-Item $CargoDir -Recurse -Force
}

Write-Host ""
Write-Host "======================================================" -ForegroundColor Green
Write-Host " BUILD COMPLETE" -ForegroundColor Green
Write-Host "======================================================" -ForegroundColor Green
Write-Host ""

# List built artifacts
Write-Host "[ARTIFACTS]"
Get-ChildItem "$ScriptDir\*.dll" | ForEach-Object {
    Write-Host "  $($_.Name) - $($_.Length) bytes"
}
