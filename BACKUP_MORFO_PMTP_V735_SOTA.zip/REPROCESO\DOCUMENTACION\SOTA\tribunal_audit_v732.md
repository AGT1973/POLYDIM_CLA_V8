# POLYDIM V732 - TRIBUNAL AUDIT & SOTA CONSOLIDATION (RULE 19)

## 1. Deduplicated Critical Findings (Bugs & Silent Failures)

Cross-referencing the evaluations from Claude, Kimi, and DeepSeek reveals structural flaws in the V732 Industrial implementation:

1. **Ghost Orchestrator / Fake Validation (Kimi & Claude):** 
   - The Rust backend is loaded but never invoked for actual cross-validation.
   - The Triton GPU backend is registered but ignored by the `run_benchmark` loop.
   - The `check_hamming_distance` metric is claimed in the README but never actually measured or asserted in the monolith.
2. **C++ Fallback Isometry Break (Kimi):**
   - In `bsc_isometry_single_step`, an out-of-bounds LUT index triggers a silent fallback (`tensor[i] ^ fixed_mask[i]`). This destroys the isometry silently without raising an error.
3. **LUT Bijectivity Hazard (Kimi):**
   - The C++ kernel accepts any `uint64_t` array as a permutation. If there are duplicates, the map is no longer injective, destroying information silently even if bounds are valid.
4. **XorShift64 Seed Hazard & Decorrelation (Kimi & Claude):**
   - `local_state = seed + thread_id + 1`. If `seed = UINT64_MAX` and `thread_id = 0`, state wraps to 0, permanently breaking XorShift64 (returns 0).
   - Poor decorrelation for close seeds.
   - **Cross-hardware non-determinism:** The random vector `v` depends on `OMP_NUM_THREADS`. Different core counts yield different mathematically generated vectors.
5. **Triton Precision Collapse (Kimi):**
   - `tensor_vals * v_vals` is executed in `float32` BEFORE casting to `float64`. The precision is already lost before the accumulation step.
6. **Package Incompleteness (Claude & Kimi):**
   - The required files `test_invariants.py`, `Cargo.toml`, and `build.ps1` were missing from the delivery folder evaluated by the AIs.
7. **Padding Bit Contamination (Claude):**
   - If $D$ is not a multiple of 64, the trailing bits of the last `uint64` block are randomized padding. The Hamming weight/distance calculations will silently count this garbage unless masked.
8. **README Snippet Trap (Claude):**
   - The `np.random.default_rng().integers(0, 2**64, dtype=np.uint64, endpoint=True)` code snippet in the README causes a `ValueError` in NumPy (out of bounds for uint64), even though the actual Python code correctly uses `np.iinfo(np.uint64).max`.

## 2. Emerging SOTA Elements & Architectural Upgrades

### A. Algebraic Isometry Composition (Kimi)
- Iterating $T(x) = x[\pi] \oplus c$ 50 times sequentially is $O(50N)$. 
- **SOTA:** It has a closed form $T^{50}(x) = x[\pi^{50}] \oplus S$, where $S = \bigoplus_{j=0}^{49} c[\pi^j]$. This can be computed in a single $O(N)$ pass, yielding bitwise identical results 33x faster.

### B. Fixed-Tree KBN Reduction & ReproBLAS (DeepSeek & Claude)
- OpenMP `reduction(+)` depends on the thread scheduler, producing non-deterministic float64 tails.
- **SOTA:** Use a ReproBLAS-style fixed binary tree reduction (Knuth TwoSum / Kahan-Babuska-Neumaier) over blocks. This guarantees bitwise reproducibility across machines regardless of core count.

### C. FMA (Fused Multiply-Add) Householder (DeepSeek)
- The expression $x - 2\langle x,v \rangle v$ suffers from double rounding.
- **SOTA:** `std::fma(-2.0*dot, v[i], tensor[i])` ensures a single rounding step. Combined with generating $v$ in strict `double/f64` (Mezzadri RNG approach), this drastically reduces isometric drift.

### D. Counter-RNG: Philox4x32 (Claude & Kimi)
- XorShift64 is statistically weak and state-dependent.
- **SOTA:** Use Philox4x32 (Salmon et al., 2011). It is a counter-based RNG ($f_{seed}(counter) = random\_value$). It is stateless, trivial to parallelize, and immune to the `OMP_NUM_THREADS` correlation bug. Supported natively by NumPy's `np.random.Philox`.

### E. Block Householder (WY Representation) (Kimi)
- $H_1 H_2 ... H_{50} = I - V T V^T$. This LAPACK standard representation allows applying 50 reflections as a single block operation (5.1x speedup).
- **Trade-off:** Kimi notes this brings back `float32` class precision errors at scale ($5\times10^{-3}$ residual) and requires massive memory for $V$ ($2GB$). Best left for GPU / Tensor Cores.

### F. Paired Benchmarks & Hardware Dispatch (DeepSeek & Claude)
- Running NumPy completely, then C++ completely introduces thermal throttling bias.
- **SOTA:** Counter-balanced, paired benchmarks (run A, then B on the same seed, compute $\Delta$).
- **SOTA:** C++ Multi-versioning (Runtime CPU Dispatch) to leverage AVX-512 without crashing on older hardware, rather than hardcoding `/arch:AVX512`.

## 3. Alternative Solutions Weighed

| Problem | Option A (Current/Fix) | Option B (SOTA) | Verdict |
|---------|------------------------|-----------------|---------|
| RNG Decorrelation | Fix XorShift64 seed logic & use SplitMix64 pre-mixer | **Adopt Philox4x32** | **Option B**. Philox eliminates cross-thread correlation and state zero hazards permanently. |
| Deterministic Sums | `reduction(+)` in OpenMP | **Fixed-Tree KBN (ReproBLAS)** | **Option B**. Mandatory for the "fixed seeds, statistical rigor" dogma of the project. |
| BSC 50 Iterations | Run `bsc_isometry` 50x in C++ | **Algebraic $T^{50}$ Composition** | **Option B**. 33x speedup with bitwise exactness. Keep 50x loop purely as the Rust reference validator. |
| Precision Householder | Float32 $v$ + standard arithmetic | **Float64 $v$ + `std::fma`** | **Option B**. FMA + f64 generator for $v$ (DeepSeek) eliminates the $\|v\| \neq 1$ systematic error. |

## 4. Next Steps (Production Release Gate)
Under Rule 19, code generation remains VETOED until the user formally unlocks the pipeline.
When unlocked, the agent must implement:
1. `kernel_cpp_v733` with Philox RNG, Fixed-Tree KBN, FMA Householder, and strict ABI checks for bijective LUTs.
2. `polydim_v733_monolito.py` with Paired Benchmarks, active Rust/Triton bindings, and $T^{50}$ composition.
3. `kernel_rust_v733` updated to run independent validation of the C++ results on every run.
